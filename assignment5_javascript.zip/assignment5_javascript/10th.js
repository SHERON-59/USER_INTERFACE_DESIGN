let books = [
    { title: "Book 1", author: "Author 1", cost: 450 },
    { title: "Book 2", author: "Mahatma Gandhi", cost: 600 },
    { title: "Book 3", author: "Author 3", cost: 700 }
];

let expensiveBooks = books.filter(book => book.cost > 500);
console.log("Books with cost > 500:", expensiveBooks);

let gandhiBook = books.find(book => book.author === "Mahatma Gandhi");
console.log("Book by Mahatma Gandhi:", gandhiBook.title);