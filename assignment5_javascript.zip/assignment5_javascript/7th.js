let str = "Please locate where 'locate' occurs!";
let index = str.indexOf("locate");
console.log("Index of 'locate':", index);