function factorial(n) {
    if (n === 0 || n === 1) return 1;
    return n * factorial(n - 1);
}

let num = parseInt(prompt("Enter a number:"));
let result = factorial(num);
console.log("Factorial:", result);
alert("Factorial: " + result);