function findMax(arr) {
    return Math.max(...arr);
}

let numbers = [10, 20, 5, 30, 15];
console.log("Highest value:", findMax(numbers));