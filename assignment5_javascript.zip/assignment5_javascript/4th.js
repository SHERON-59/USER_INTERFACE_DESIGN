let temperature = parseFloat(prompt("Enter the temperature:"));

if (temperature < 0) {
    console.log("Freezing");
} else if (temperature >= 0 && temperature <= 15) {
    console.log("Cold");
} else if (temperature >= 16 && temperature <= 30) {
    console.log("Moderate");
} else {
    console.log("Hot");
}