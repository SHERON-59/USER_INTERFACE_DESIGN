let number = prompt("Enter a number:");
function factorial(n) {
    if (n === 0 || n === 1) return 1;
    return n * factorial(n - 1);
}
let result = factorial(Number(number));
console.log("Factorial:", result);
alert("Factorial is " + result);
